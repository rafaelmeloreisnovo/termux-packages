if [ ! -e /data/data/com.termux.rafacodephi/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.termux.rafacodephi/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.termux.rafacodephi/files/home/.config/termux/
	cp /data/data/com.termux.rafacodephi/files/usr/share/examples/termux/termux.properties /data/data/com.termux.rafacodephi/files/home/.config/termux/termux.properties
fi
