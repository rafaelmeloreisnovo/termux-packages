##
## This script is sourced by /data/data/com.termux.rafacodephi/files/usr/bin/login before executing shell.
##
